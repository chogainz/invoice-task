 
<?php $__env->startSection('content'); ?>
<div class="container">

  <button class="btn btn-primary mb-3" onclick="window.location = '<?php echo e(route('invoice.create')); ?>'">Create Invoice</button>

  <div class="d-flex">
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Date</th>
          <th scope="col">Due</th>
          <th scope="col">Details</th>
          <th scope="col">Client</th>
          <th scope="col">Paid</th>
          <th scope="col">Total</th>
        </tr>
      </thead>
      <tbody>

        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr style="cursor:pointer" onclick="window.location.href='<?php echo e(route('invoice.show', $invoice->id)); ?>'">

          <td><?php echo e($invoice->date); ?></td>
          <td><?php echo e($invoice->days); ?></td>
          <td><?php echo e($invoice->description); ?></td>
          <td><?php echo e($invoice->client->name); ?></td>
          <td><?php echo e($invoice['invoice_paid']?'paid':'unpaid'); ?></td>
          <td><?php echo e($invoice->total); ?></td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>