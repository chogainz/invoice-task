 
<?php $__env->startSection('content'); ?>
<div class="container">

  

  <form role="form" method="POST">

    <?php echo e(csrf_field()); ?> <?php echo e(method_field('PATCH')); ?>

    <div class="d-flex flex-column mb-3">
      <div class="input-group input-group-sm mb-1">
        <div class="input-group-prepend">
          <span class="input-group-text" id="inputGroup-sizing-sm">Title</span>
        </div>
        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->title); ?>">
      </div>

      <div class="input-group mb-1">
        <div class="input-group-prepend">
          <span class="input-group-text">Description</span>
        </div>
        <textarea class="form-control" aria-label="With textarea" value="<?php echo e($invoice->description); ?>"><?php echo e($invoice->description); ?></textarea>
      </div>


      <div class="input-group input-group-sm mb-1">
        <div class="input-group-prepend">
          <span class="input-group-text" id="inputGroup-sizing-sm">Invoice number</span>
        </div>
        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice['invoice_number']); ?>">
      </div>

    </div>

    <div class="d-flex mb-3">
      <div>
        Language
        <select class="custom-select" name="" id=""><option>English</option></select>
      </div>

      <div>
        Currency
        <select class="custom-select" name="" id=""><option>United States Doller</option></select>
      </div>

    </div>

    <div class="d-flex flex-column mb-3">

      From
      <div>

        <div class="input-group input-group-sm mb-1">
          <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroup-sizing-sm">Name</span>
          </div>
          <input disabled type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->user->name); ?>">
        </div>

        <div class="input-group input-group-sm mb-1">
          <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroup-sizing-sm">Street</span>
          </div>
          <input disabled type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->user->street); ?>">
        </div>

        <div class="input-group input-group-sm mb-1">
          <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroup-sizing-sm">City</span>
          </div>
          <input disabled type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->user->city); ?>">
        </div>

        <div class="input-group input-group-sm mb-1">
          <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroup-sizing-sm">Postcode</span>
          </div>
          <input disabled type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->user->postcode); ?>">
        </div>

        <div class="input-group input-group-sm mb-1">
          <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroup-sizing-sm">Country</span>
          </div>
          <input disabled type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->user->country); ?>">
        </div>

      </div>

      <div>
        To

        <div class="input-group input-group-sm mb-1">
          <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroup-sizing-sm">Name</span>
          </div>
          <input type="text" class="form-control input-name" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->client->name); ?>">
        </div>

        <div class="input-group input-group-sm mb-1">
          <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroup-sizing-sm">Street</span>
          </div>
          <input type="text" class="form-control input-street" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->client->street); ?>">
        </div>

        <div class="input-group input-group-sm mb-1">
          <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroup-sizing-sm">City</span>
          </div>
          <input type="text" class="form-control input-city" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->client->city); ?>">
        </div>

        <div class="input-group input-group-sm mb-1">
          <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroup-sizing-sm">Postcode</span>
          </div>
          <input type="text" class="form-control input-postcode" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->client->postcode); ?>">
        </div>

        <div class="input-group input-group-sm mb-1">
          <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroup-sizing-sm">Country</span>
          </div>
          <input type="text" class="form-control input-country" aria-label="Small" aria-describedby="inputGroup-sizing-sm" name="country"
            value="<?php echo e($invoice->client->country); ?>">
        </div>

      </div>

    </div>

    <div class="d-flex flex-column mb-3">

      <div class="input-group input-group-sm mb-1">
        <div class="input-group-prepend">
          <span class="input-group-text" id="inputGroup-sizing-sm">date</span>
        </div>
        <input type="date" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->date); ?>">
      </div>

      <div class="input-group input-group-sm mb-1">
        <div class="input-group-prepend">
          <span class="input-group-text" id="inputGroup-sizing-sm">Invoice date</span>
        </div>
        <input type="date" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice['invoice_date']); ?>">
      </div>

      <div class="input-group input-group-sm mb-1">
        <div class="input-group-prepend">
          <span class="input-group-text" id="inputGroup-sizing-sm">Purchase order number</span>
        </div>
        <input type="text" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice['purchase_order_number']); ?>">
      </div>

    </div>

    <div class="d-flex flex-column mb-3">

      Items

      <div class="input-group mb-1">
        <div class="input-group-prepend">
          <span class="input-group-text">Name & description</span>
        </div>
        <textarea class="form-control" aria-label="With textarea" value="<?php echo e($invoice->item['name_description']); ?>"><?php echo e($invoice->item['name_description']); ?></textarea>
      </div>


      <div class="input-group input-group-sm mb-1">
        <div class="input-group-prepend">
          <span class="input-group-text" id="inputGroup-sizing-sm">Quantity</span>
        </div>
        <input type="text" class="form-control input-quantity" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->item->quantity); ?>">
      </div>


      <div class="input-group input-group-sm mb-1">
        <div class="input-group-prepend">
          <span class="input-group-text" id="inputGroup-sizing-sm">Price</span>
        </div>
        <input type="text" class="form-control input-price" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->item->unit); ?>">
      </div>



      <div class="input-group input-group-sm mb-1">
        <div class="input-group-prepend">
          <span class="input-group-text" id="inputGroup-sizing-sm">Total</span>
        </div>
        <input type="text" class="form-control input-total" aria-label="Small" aria-describedby="inputGroup-sizing-sm" value="<?php echo e($invoice->total); ?>">
      </div>

    </div>


    <div class="d-flex flex-column mb-3">
      Invoice note
      <div class="input-group">
        <div class="input-group-prepend">
          <span class="input-group-text">Invoice note</span>
        </div>
        <textarea class="form-control" aria-label="With textarea" value="<?php echo e($invoice['invoice_note']); ?>"><?php echo e($invoice['invoice_note']); ?></textarea>
      </div>
    </div>
  </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>