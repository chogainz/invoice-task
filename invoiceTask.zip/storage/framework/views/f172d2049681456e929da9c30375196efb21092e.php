 
<?php $__env->startSection('content'); ?>
<div class="container">

  <button class="btn btn-success mb-3" onclick="window.location = '<?php echo e(route('invoices.create')); ?>'">Create Invoice</button>

  <div class="d-flex">
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Date</th>
          <th scope="col">Due</th>
          <th scope="col">Details</th>
          <th scope="col">Client</th>
          <th scope="col">Total</th>
          <th scope="col">Status</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>

        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr style="cursor:pointer">

          <td><?php echo e($invoice->date); ?></td>
          <td><?php echo e($invoice->days); ?></td>
          <td><?php echo e($invoice->description); ?></td>
          <td><?php echo e($invoice->client->name); ?></td>
          <td>£<?php echo e($invoice->total); ?></td>
          <td><?php echo e($invoice['invoice_paid']?'paid':'unpaid'); ?></td>
          <td class="d-flex">
            <button type="button" class="btn btn-primary mr-2" onclick="window.location = '<?php echo e(route('invoices.show',['id'=>$invoice->id])); ?>'">View</button>
            <form role="form" method="POST" action="<?php echo e(route('invoices.destroy',['id'=>$invoice->id])); ?>">
              <?php echo e(csrf_field()); ?> <?php echo e(method_field('DELETE')); ?>

              <button class="btn btn-danger">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>